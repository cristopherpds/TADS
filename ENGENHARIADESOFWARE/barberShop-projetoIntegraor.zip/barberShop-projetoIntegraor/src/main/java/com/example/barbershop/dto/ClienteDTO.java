package com.example.barbershop.dto;

public record ClienteDTO(int id, String nome, String telefone, String email, String cpf) {

}
