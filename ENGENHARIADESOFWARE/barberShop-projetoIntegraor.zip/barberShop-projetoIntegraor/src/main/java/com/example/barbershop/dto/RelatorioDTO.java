package com.example.barbershop.dto;

public record RelatorioDTO(int id, String vendaPorDia, String vendaPorFuncionario, String produtosMaisVendidos) {
    
}
