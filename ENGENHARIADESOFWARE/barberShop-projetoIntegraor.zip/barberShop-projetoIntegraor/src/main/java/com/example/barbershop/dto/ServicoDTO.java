package com.example.barbershop.dto;

public record ServicoDTO(int id, String name, String duracao, Double valor) {
    
}
