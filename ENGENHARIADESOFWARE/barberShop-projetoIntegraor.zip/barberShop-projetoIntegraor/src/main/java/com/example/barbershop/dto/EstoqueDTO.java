package com.example.barbershop.dto;

public record EstoqueDTO(int id,ProdutoDTO produtos) {

}
