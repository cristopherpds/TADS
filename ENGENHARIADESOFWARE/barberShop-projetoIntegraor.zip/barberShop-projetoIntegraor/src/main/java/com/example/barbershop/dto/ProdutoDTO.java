package com.example.barbershop.dto;

public record ProdutoDTO(int id, String descricao, double preco, int quantEmEstoque) {
    
}
